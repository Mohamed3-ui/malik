function calculateTotal() {

    const checkboxes = document.querySelectorAll('#food-order-form input[type="checkbox"]');

    let total = 0;

    checkboxes.forEach(checkbox => {

        if (checkbox.checked) {

            total += parseFloat(checkbox.getAttribute('data-price'));

        }

    });

    document.getElementById('total').innerText = total.toFixed(2);

}

document.querySelectorAll('#food-order-form input[type="checkbox"]').forEach(checkbox => {

    checkbox.addEventListener('change', calculateTotal);

});

function placeOrder() {

    const customerName = document.getElementById('customer-name').value;

    const customerNumber = document.getElementById('customer-number').value;

    if (!customerName || !customerNumber) {

        alert('Please enter your name and number.');

        return;

    }

    const checkboxes = document.querySelectorAll('#food-order-form input[type="checkbox"]');

    let orderDetails = `Name: ${customerName}\nNumber: ${customerNumber}\nOrder details:\n`;

    let total = 0;

    checkboxes.forEach(checkbox => {

        if (checkbox.checked) {

            orderDetails += `${checkbox.value}: $${checkbox.getAttribute('data-price')}\n`;

            total += parseFloat(checkbox.getAttribute('data-price'));

        }

    });

    if (total === 0) {

        alert('Please select at least one item to order.');

        return;

    }

    orderDetails += `Total: $${total.toFixed(2)}`;

    const whatsappLink = `https://wa.me/252636308220?text=${encodeURIComponent(orderDetails)}`;

    window.open(whatsappLink, '_blank');

}

let orderingEnabled = true;

function toggleOrdering() {

    const formElements = document.querySelectorAll('#food-order-form input, #placeOrderBtn');

    orderingEnabled = !orderingEnabled;

    formElements.forEach(element => {

        element.disabled = !orderingEnabled;

    });

    const toggleOrderBtn = document.getElementById('toggleOrderBtn');

    toggleOrderBtn.innerText = orderingEnabled ? 'Disable Ordering' : 'Enable Ordering';

    toggleOrderBtn.style.backgroundColor = orderingEnabled ? 'red' : 'green';

    alert(orderingEnabled ? 'Ordering enabled' : 'Ordering disabled');

}